# PassCraft - Ticket Booking Website

A modern, responsive full-stack Ticket Booking Application built with **HTML5**, **CSS3**, **Vanilla JavaScript (ES6)**, and **Node.js (Express)** backend.

## 🌟 Features

- **Event Catalog**: Browse upcoming Movies, Concerts, Conferences, and Travel routes.
- **Category Filtering**: Filter shows by category (Movies, Concerts, Conferences, Travel).
- **Interactive Ticket Booking**:
  - Live seat availability check.
  - Ticket quantity controls with real-time price summary calculation.
  - Customer name, email, and phone input validation.
  - Automatic ticket code generation (e.g. `TKT-A9B8C7`).
- **My Bookings Manager**:
  - Digital Pass list with ticket codes, event dates, and total paid amount.
  - Real-time **Cancel Booking** feature that restores available seats back to the event.
- **Toast Notifications**: Modern pop-up alerts for user feedback.
- **REST API Backend**: Express server handling `GET`, `POST`, and `DELETE` endpoints.

---

## 📁 Directory Structure

```text
ticket-booking-website/
├── package.json          # Node dependencies and npm scripts
├── server.js             # Express REST API server & static file host
├── public/               # Frontend assets served by Express
│   ├── index.html        # Main web page layout
│   ├── styles.css        # Responsive, modern UI styling
│   └── script.js         # Frontend interactive logic & API fetch
└── README.md             # Project documentation
```

---

## 🚀 How to Run the Website

### Prerequisites
Make sure you have **Node.js** installed on your system. You can check by running:
```bash
node -v
```

### Steps to Start Server

1. **Open Terminal** in the `ticket-booking-website` folder:
   ```bash
   cd ticket-booking-website
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Start the Express Server**:
   ```bash
   npm start
   ```

4. **Open in Browser**:
   Navigate to: [http://localhost:3000](http://localhost:3000)

---

## 🔌 API Endpoints Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/events` | Get all available events & seat counts |
| `GET` | `/api/events/:id` | Get details for a specific event |
| `GET` | `/api/bookings` | Get all user bookings |
| `POST` | `/api/bookings` | Create a new ticket booking |
| `DELETE` | `/api/bookings/:id` | Cancel a booking and release seats |
