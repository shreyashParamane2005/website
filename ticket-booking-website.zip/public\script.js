document.addEventListener('DOMContentLoaded', () => {
  // State
  let allEvents = [];
  let currentCategory = 'All';
  let activeEvent = null;

  // DOM Elements
  const eventsGrid = document.getElementById('events-grid');
  const resultsCount = document.getElementById('results-count');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const bookingCountBadge = document.getElementById('booking-count-badge');

  // Modals
  const bookingModal = document.getElementById('booking-modal');
  const closeBookingModalBtn = document.getElementById('close-booking-modal');
  const myBookingsModal = document.getElementById('my-bookings-modal');
  const navBookingsBtn = document.getElementById('nav-bookings-btn');
  const closeBookingsModalBtn = document.getElementById('close-bookings-modal');
  const navEventsBtn = document.getElementById('nav-events-btn');

  // Booking Form & Quantity Controls
  const bookingForm = document.getElementById('booking-form');
  const qtyMinusBtn = document.getElementById('qty-minus');
  const qtyPlusBtn = document.getElementById('qty-plus');
  const qtyInput = document.getElementById('ticket-quantity');
  const modalUnitPrice = document.getElementById('summary-unit-price');
  const modalSummaryQty = document.getElementById('summary-qty');
  const modalTotalPrice = document.getElementById('summary-total-price');

  // Initialize
  fetchEvents();
  fetchBookingsCount();

  // Event Listeners
  filterBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      filterBtns.forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      currentCategory = e.target.getAttribute('data-category');
      renderEvents();
    });
  });

  // Modal Controls
  closeBookingModalBtn.addEventListener('click', () => closeModal(bookingModal));
  closeBookingsModalBtn.addEventListener('click', () => closeModal(myBookingsModal));

  navBookingsBtn.addEventListener('click', () => {
    openMyBookingsModal();
  });

  navEventsBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Close modal when clicking on overlay background
  [bookingModal, myBookingsModal].forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal(modal);
    });
  });

  // Quantity Controls
  qtyMinusBtn.addEventListener('click', () => {
    let val = parseInt(qtyInput.value) || 1;
    if (val > 1) {
      qtyInput.value = val - 1;
      updatePriceSummary();
    }
  });

  qtyPlusBtn.addEventListener('click', () => {
    let val = parseInt(qtyInput.value) || 1;
    if (activeEvent && val < activeEvent.availableSeats && val < 10) {
      qtyInput.value = val + 1;
      updatePriceSummary();
    } else {
      showToast('Maximum available seats reached', 'error');
    }
  });

  // Booking Form Submit
  bookingForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const eventId = document.getElementById('modal-event-id').value;
    const userName = document.getElementById('user-name').value.trim();
    const userEmail = document.getElementById('user-email').value.trim();
    const userPhone = document.getElementById('user-phone').value.trim();
    const quantity = parseInt(qtyInput.value);

    if (!userName || !userEmail) {
      showToast('Please fill in required fields.', 'error');
      return;
    }

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventId,
          userName,
          userEmail,
          userPhone,
          quantity
        })
      });

      const result = await response.json();

      if (result.success) {
        showToast(`🎉 Ticket Booked! Code: ${result.data.bookingCode}`, 'success');
        closeModal(bookingModal);
        bookingForm.reset();

        // Refresh event seats and booking badge
        fetchEvents();
        fetchBookingsCount();
      } else {
        showToast(result.message || 'Booking failed', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Failed to connect to server.', 'error');
    }
  });

  // Functions

  // Fetch Events from API
  async function fetchEvents() {
    try {
      resultsCount.textContent = 'Updating live shows...';
      const response = await fetch('/api/events');
      const result = await response.json();

      if (result.success) {
        allEvents = result.data;
        renderEvents();
      }
    } catch (err) {
      console.error('Error fetching events:', err);
      resultsCount.textContent = 'Error loading events.';
      eventsGrid.innerHTML = '<p class="empty-bookings">Failed to load events. Make sure server is running.</p>';
    }
  }

  // Render Filtered Events
  function renderEvents() {
    const filtered = currentCategory === 'All'
      ? allEvents
      : allEvents.filter(e => e.category === currentCategory);

    resultsCount.textContent = `Showing ${filtered.length} show(s)`;

    if (filtered.length === 0) {
      eventsGrid.innerHTML = '<p class="empty-bookings">No events found in this category.</p>';
      return;
    }

    eventsGrid.innerHTML = filtered.map(event => {
      const isSoldOut = event.availableSeats <= 0;

      return `
        <div class="event-card">
          <div class="card-image-wrap">
            <img src="${event.image}" alt="${event.title}" loading="lazy">
            <span class="category-tag">${event.category}</span>
          </div>
          <div class="card-body">
            <h3 class="event-title">${event.title}</h3>
            <p class="event-desc">${event.description}</p>

            <ul class="event-details-list">
              <li>📍 <strong>Venue:</strong> ${event.venue}</li>
              <li>📅 <strong>Date:</strong> ${event.date} at ${event.time}</li>
              <li>🪑 <strong>Seats Left:</strong> ${event.availableSeats} / ${event.totalSeats}</li>
            </ul>

            <div class="card-footer">
              <div class="price-tag">
                <span class="amount">$${event.price.toFixed(2)}</span>
                <span class="label">per ticket</span>
              </div>
              <button
                class="book-btn"
                onclick="openBookingModal('${event.id}')"
                ${isSoldOut ? 'disabled' : ''}>
                ${isSoldOut ? 'Sold Out' : 'Book Now'}
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  // Open Booking Modal for an Event
  window.openBookingModal = (eventId) => {
    activeEvent = allEvents.find(e => e.id === eventId);
    if (!activeEvent) return;

    document.getElementById('modal-event-id').value = activeEvent.id;
    document.getElementById('modal-event-category').textContent = activeEvent.category;
    document.getElementById('modal-event-title').textContent = activeEvent.title;
    document.getElementById('modal-event-meta').textContent = `📍 ${activeEvent.venue} | 📅 ${activeEvent.date} (${activeEvent.time})`;
    document.getElementById('modal-available-seats').textContent = `Available seats: ${activeEvent.availableSeats}`;

    qtyInput.value = 1;
    updatePriceSummary();
    openModal(bookingModal);
  };

  // Update Modal Price Calculations
  function updatePriceSummary() {
    if (!activeEvent) return;
    const qty = parseInt(qtyInput.value) || 1;
    const total = activeEvent.price * qty;

    modalUnitPrice.textContent = `$${activeEvent.price.toFixed(2)}`;
    modalSummaryQty.textContent = qty;
    modalTotalPrice.textContent = `$${total.toFixed(2)}`;
  }

  // Open My Bookings Modal
  async function openMyBookingsModal() {
    openModal(myBookingsModal);
    const container = document.getElementById('bookings-list-container');
    container.innerHTML = '<p class="empty-bookings">Loading your bookings...</p>';

    try {
      const response = await fetch('/api/bookings');
      const result = await response.json();

      if (result.success) {
        const bookings = result.data;
        bookingCountBadge.textContent = bookings.length;

        if (bookings.length === 0) {
          container.innerHTML = '<div class="empty-bookings"><p>🎟️ No tickets booked yet.</p><p>Browse shows and book your first pass!</p></div>';
          return;
        }

        container.innerHTML = bookings.map(b => `
          <div class="ticket-card">
            <div class="ticket-info">
              <span class="ticket-code">${b.bookingCode}</span>
              <h4>${b.eventTitle}</h4>
              <p class="ticket-details-text">📍 ${b.venue}</p>
              <p class="ticket-details-text">📅 ${b.eventDate} at ${b.eventTime} | 👤 ${b.userName} (${b.quantity} Ticket(s))</p>
              <p class="ticket-details-text">💵 Total Paid: <strong>$${b.totalPrice.toFixed(2)}</strong></p>
            </div>
            <button class="cancel-btn" onclick="cancelBooking('${b.id}')">Cancel Booking</button>
          </div>
        `).join('');
      }
    } catch (err) {
      console.error(err);
      container.innerHTML = '<p class="empty-bookings">Failed to fetch bookings.</p>';
    }
  }

  // Cancel Booking
  window.cancelBooking = async (bookingId) => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;

    try {
      const response = await fetch(`/api/bookings/${bookingId}`, { method: 'DELETE' });
      const result = await response.json();

      if (result.success) {
        showToast('Booking cancelled successfully', 'success');
        openMyBookingsModal(); // Refresh modal
        fetchEvents(); // Refresh event seats
        fetchBookingsCount();
      } else {
        showToast(result.message || 'Failed to cancel', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Error cancelling booking', 'error');
    }
  };

  // Fetch Booking Count for Badge
  async function fetchBookingsCount() {
    try {
      const response = await fetch('/api/bookings');
      const result = await response.json();
      if (result.success) {
        bookingCountBadge.textContent = result.data.length;
      }
    } catch (err) {
      console.error(err);
    }
  }

  // Helper Functions
  function openModal(modal) {
    modal.classList.add('active');
  }

  function closeModal(modal) {
    modal.classList.remove('active');
  }

  function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `${type === 'success' ? '✅' : '⚠️'} ${message}`;

    container.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3500);
  }
});
