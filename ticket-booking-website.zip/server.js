const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-Memory Database
let events = [
  {
    id: 'evt-1',
    title: 'Avatar: Fire and Ice Premiere',
    category: 'Movie',
    date: '2025-04-15',
    time: '07:30 PM',
    venue: 'Cineplex IMAX - Screen 1',
    price: 15.00,
    availableSeats: 45,
    totalSeats: 60,
    image: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&q=80',
    description: 'Experience the epic cinematic journey on the largest IMAX screen with immersive Dolby Atmos audio.'
  },
  {
    id: 'evt-2',
    title: 'CyberTech World Summit 2025',
    category: 'Conference',
    date: '2025-05-10',
    time: '09:00 AM',
    venue: 'Metropolitan Convention Center',
    price: 85.00,
    availableSeats: 120,
    totalSeats: 200,
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=600&q=80',
    description: 'Join industry pioneers for inspiring keynotes on Artificial Intelligence, Web Dev, and Cybersecurity.'
  },
  {
    id: 'evt-3',
    title: 'Symphony Night Under the Stars',
    category: 'Concert',
    date: '2025-04-20',
    time: '08:00 PM',
    venue: 'Royal Amphitheater Park',
    price: 40.00,
    availableSeats: 18,
    totalSeats: 100,
    image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
    description: 'A breathtaking live orchestral performance featuring timeless classical masterpieces.'
  },
  {
    id: 'evt-4',
    title: 'Intercity Bullet Express (Express-102)',
    category: 'Travel',
    date: '2025-04-18',
    time: '06:15 AM',
    venue: 'Central Terminal - Platform 4',
    price: 28.50,
    availableSeats: 32,
    totalSeats: 80,
    image: 'https://images.unsplash.com/photo-1515165562839-978bbcf18277?auto=format&fit=crop&w=600&q=80',
    description: 'High-speed luxury rail transport connecting major metro cities with free Wi-Fi and breakfast.'
  }
];

let bookings = [];

// API Endpoints

// 1. Get all events
app.get('/api/events', (req, res) => {
  res.json({
    success: true,
    data: events
  });
});

// 2. Get single event detail
app.get('/api/events/:id', (req, res) => {
  const event = events.find(e => e.id === req.params.id);
  if (!event) {
    return res.status(404).json({ success: false, message: 'Event not found' });
  }
  res.json({ success: true, data: event });
});

// 3. Get all bookings
app.get('/api/bookings', (req, res) => {
  res.json({
    success: true,
    data: bookings
  });
});

// 4. Create a new ticket booking
app.post('/api/bookings', (req, res) => {
  const { eventId, userName, userEmail, userPhone, quantity, seats } = req.body;

  // Validation
  if (!eventId || !userName || !userEmail || !quantity || quantity <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Please provide all required fields (eventId, name, email, valid quantity).'
    });
  }

  const eventIndex = events.findIndex(e => e.id === eventId);
  if (eventIndex === -1) {
    return res.status(404).json({ success: false, message: 'Event not found.' });
  }

  const event = events[eventIndex];

  if (event.availableSeats < quantity) {
    return res.status(400).json({
      success: false,
      message: `Not enough seats available! Only ${event.availableSeats} remaining.`
    });
  }

  // Deduct available seats
  events[eventIndex].availableSeats -= quantity;

  // Calculate total price
  const totalPrice = Number((event.price * quantity).toFixed(2));

  // Generate Booking Code
  const bookingCode = 'TKT-' + Math.random().toString(36).substring(2, 8).toUpperCase();

  const newBooking = {
    id: 'bk-' + Date.now(),
    bookingCode,
    eventId: event.id,
    eventTitle: event.title,
    eventCategory: event.category,
    eventDate: event.date,
    eventTime: event.time,
    venue: event.venue,
    userName,
    userEmail,
    userPhone: userPhone || 'N/A',
    quantity: Number(quantity),
    seats: seats || `Seats A1-A${quantity}`,
    totalPrice,
    bookedAt: new Date().toISOString(),
    status: 'CONFIRMED'
  };

  bookings.unshift(newBooking);

  res.status(201).json({
    success: true,
    message: 'Ticket booked successfully!',
    data: newBooking
  });
});

// 5. Cancel a booking
app.delete('/api/bookings/:id', (req, res) => {
  const bookingIndex = bookings.findIndex(b => b.id === req.params.id);

  if (bookingIndex === -1) {
    return res.status(404).json({ success: false, message: 'Booking not found.' });
  }

  const cancelledBooking = bookings[bookingIndex];

  // Restore available seats back to the event
  const eventIndex = events.findIndex(e => e.id === cancelledBooking.eventId);
  if (eventIndex !== -1) {
    events[eventIndex].availableSeats += cancelledBooking.quantity;
  }

  // Remove booking
  bookings.splice(bookingIndex, 1);

  res.json({
    success: true,
    message: 'Booking cancelled successfully. Seats restored.',
    data: { id: req.params.id }
  });
});

// Fallback route for SPA / index
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`=================================================`);
  console.log(`Ticket Booking Server is running on port ${PORT}`);
  console.log(`Open in Browser: http://localhost:${PORT}`);
  console.log(`=================================================`);
});
